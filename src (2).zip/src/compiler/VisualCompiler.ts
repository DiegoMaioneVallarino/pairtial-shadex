import type {
  VisualProgram,
} from "../ir/visual-ir.types";


function floatLiteral(
  value: number,
) {
  if (
    Number.isInteger(value)
  ) {
    return `${value}.0`;
  }

  return String(value);
}


function vec3Literal(
  value: [
    number,
    number,
    number,
  ],
) {
  return `vec3(
    ${floatLiteral(value[0])},
    ${floatLiteral(value[1])},
    ${floatLiteral(value[2])}
  )`;
}


function variable(
  id: string,
) {
  return `v_${id.replace(
    /[^a-zA-Z0-9_]/g,
    "_",
  )}`;
}


export function compileVisualProgram(
  program: VisualProgram,
): string {
  const lines: string[] = [];


  for (
    const operation of
    program.operations
  ) {
    const target =
      variable(operation.id);


    switch (
      operation.type
    ) {
     case "coordinates": {
  lines.push(`
vec2 ${target} =
  (v_uv - 0.5) * 2.0;

${target}.x *=
  u_resolution.x /
  u_resolution.y;
`);

  break;
}

case "sphere-distance": {
  const input =
    variable(
      operation.input,
    );

  const radius =
    variable(
      operation.radius,
    );

  lines.push(`
float ${target} =
  length(${input}) -
  ${radius};
`);

  break;
}


     case "constant": {
  lines.push(`
float ${target} =
  ${floatLiteral(
    operation.value,
  )};
`);

  break;
}


case "time": {
  lines.push(`
float ${target} =
  u_time;
`);

  break;
}


case "multiply": {
  const a =
    variable(
      operation.a,
    );

  const b =
    variable(
      operation.b,
    );

  lines.push(`
float ${target} =
  ${a} * ${b};
`);

  break;
}


case "add": {
  const a =
    variable(
      operation.a,
    );

  const b =
    variable(
      operation.b,
    );

  lines.push(`
float ${target} =
  ${a} + ${b};
`);

  break;
}


case "sin": {
  const input =
    variable(
      operation.input,
    );

  lines.push(`
float ${target} =
  sin(${input});
`);

  break;
}


      case "distort-distance": {
  const input =
    variable(
      operation.input,
    );

  lines.push(`
float ${target} =
  ${input} -
  (
    noise(
      v_coordinates *
      ${floatLiteral(
        operation.scale,
      )} +
      u_time * 0.15
    ) - 0.5
  ) *
  ${floatLiteral(
    operation.amount,
  )};
`);

  break;
}


      case "body-mask": {
        const input =
          variable(
            operation.input,
          );

        lines.push(`
float ${target} =
  1.0 -
  smoothstep(
    0.0,
    ${floatLiteral(
      operation.softness,
    )},
    ${input}
  );
`);

        break;
      }


      case "emissive": {
        const mask =
          variable(
            operation.mask,
          );

        lines.push(`
vec3 ${target} =
  ${vec3Literal(
    operation.color,
  )} *
  ${mask} *
  ${floatLiteral(
    operation.intensity,
  )};
`);

        break;
      }


      case "glow": {
        const distance =
          variable(
            operation.distance,
          );

        const color =
          variable(
            operation.color,
          );

        lines.push(`
float ${target}_field =
  exp(
    -abs(${distance}) /
    ${floatLiteral(
      operation.radius,
    )}
  );

vec3 ${target} =
  ${color} +
  ${vec3Literal([
    0.25,
    0.55,
    1,
  ])} *
  ${target}_field *
  ${floatLiteral(
    operation.intensity,
  )};
`);

        break;
      }
case "density-field": {
  const input =
    variable(
      operation.input,
    );

  const detail =
    Math.max(
      1,
      Math.floor(
        operation.detail,
      ),
    );

  const octaveLines:
    string[] = [];

  let amplitude = 0.5;
  let frequency = 1;

  for (
    let octave = 0;
    octave < detail;
    octave += 1
  ) {
    octaveLines.push(`
${target}_noise +=
  noise(
    ${input} *
    ${floatLiteral(
      operation.scale *
        frequency,
    )}
  ) *
  ${floatLiteral(
    amplitude,
  )};
`);

    frequency *= 2;
    amplitude *= 0.5;
  }

  lines.push(`
float ${target}_noise = 0.0;

${octaveLines.join("\n")}
`);

  switch (operation.shape) {
    case "uniform": {
      lines.push(`
float ${target} =
  pow(
    clamp(
      ${target}_noise,
      0.0,
      1.0
    ),
    ${floatLiteral(
      operation.sharpness,
    )}
  );
`);

      break;
    }

    case "bands": {
      lines.push(`
float ${target}_bands =
  abs(
    sin(
      ${input}.x *
      ${floatLiteral(
        operation.scale,
      )} *
      3.14159265
    )
  );

float ${target} =
  pow(
    clamp(
      ${target}_bands *
      ${target}_noise,
      0.0,
      1.0
    ),
    ${floatLiteral(
      operation.sharpness,
    )}
  );
`);

      break;
    }
  }

  break;
}case "vertical-envelope": {
  const coordinates =
    variable(
      operation.coordinates,
    );

  const input =
    variable(
      operation.input,
    );

  lines.push(`
float ${target}_distance =
  abs(
    ${coordinates}.x -
    ${floatLiteral(
      operation.center,
    )}
  );

float ${target}_mask =
  1.0 -
  smoothstep(
    ${floatLiteral(
      operation.width,
    )},
    ${floatLiteral(
      operation.width +
        operation.softness,
    )},
    ${target}_distance
  );

float ${target} =
  ${input} *
  ${target}_mask;
`);

  break;
}case "radial-envelope": {
  const coordinates =
    variable(
      operation.coordinates,
    );

  const input =
    variable(
      operation.input,
    );

  const [
    centerX,
    centerY,
  ] = operation.center;

  lines.push(`
float ${target}_distance =
  length(
    ${coordinates} -
    vec2(
      ${floatLiteral(centerX)},
      ${floatLiteral(centerY)}
    )
  );

float ${target}_mask =
  1.0 -
  smoothstep(
    ${floatLiteral(
      operation.radius,
    )},
    ${floatLiteral(
      operation.radius +
        operation.softness,
    )},
    ${target}_distance
  );

float ${target} =
  ${input} *
  ${target}_mask;
`);

  break;
}
case "flow-coordinates": {
  const input =
    variable(
      operation.input,
    );

  const time =
    variable(
      operation.time,
    );

  const [
    directionX,
    directionY,
  ] =
    operation.direction;

  lines.push(`
vec2 ${target} =
  ${input} +
  vec2(
    ${floatLiteral(
      directionX,
    )},
    ${floatLiteral(
      directionY,
    )}
  ) *
  ${time} *
  ${floatLiteral(
    operation.speed,
  )};
`);

  break;
}
case "turbulence-coordinates": {
  const input =
    variable(
      operation.input,
    );

  const time =
    variable(
      operation.time,
    );

  const scale =
    Math.max(
      1,
      operation.detail,
    );

  lines.push(`
float ${target}_time =
  ${time} *
  ${floatLiteral(
    operation.speed,
  )};

vec2 ${target}_noise =
  vec2(
    noise(
      ${input} *
      ${floatLiteral(scale)} +
      vec2(
        ${target}_time,
        ${target}_time * 0.37
      )
    ),

    noise(
      ${input} *
      ${floatLiteral(scale)} +
      vec2(
        37.2 - ${target}_time * 0.21,
        91.7 + ${target}_time
      )
    )
  );

vec2 ${target} =
  ${input} +
  (
    ${target}_noise -
    0.5
  ) *
  ${floatLiteral(
    operation.amount,
  )};
`);

  break;
}
      case "output": {
        const color =
          variable(
            operation.color,
          );

        lines.push(`
outColor =
  vec4(
    ${color},
    1.0
  );
`);

        break;
      }
    }
  }


  return lines.join("\n");
}